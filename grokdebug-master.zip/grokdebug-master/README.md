grokdebug
=========
Forked to use custom patterns.
Added separate page for viewing loaded patterns.
